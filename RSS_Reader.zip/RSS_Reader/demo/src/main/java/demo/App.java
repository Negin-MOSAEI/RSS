package demo;


import java.util.Scanner;
import org.jsoup.Jsoup;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.jsoup.nodes.Element;


public class App {
    private static void showUpdates() {
        ArrayList<String> titles = readTitlesFromFile("data.txt");
        if (titles.isEmpty()) {
            System.out.println("No RSS found!");
            return;
        }
    
        System.out.println("Show updates for:");
        System.out.println("[0] All website");
        for (int i = 0; i < titles.size(); i++) {
            System.out.println("[" + (i + 1) + "] " + titles.get(i));
        }
        System.out.println("Enter -1 to return.");
    
        @SuppressWarnings("resource")
        Scanner localScanner = new Scanner(System.in); 
        int choice = Integer.parseInt(localScanner.nextLine()); 
    
        switch (choice) {
            case -1:
                System.out.println("");
                break;
            case 0:
                allRss();
                break;
            default:
                if (choice >= 1 && choice < titles.size() + 1) {
                    retrieveRssContent(searchRss(titles.get(choice - 1)));
                } else {
                    System.out.println("Invalid choice!");
                }
                break;
        }
    
    }

    
    public static String searchRss(String siteName) {
        try (BufferedReader reader = new BufferedReader(new FileReader("data.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length >= 3) {
                    String name = parts[0];
                    String rssUrl = parts[2];
                    if (name.equals(siteName)) {
                        return rssUrl ;
                    }
                }
            }
            System.out.println("RSS for " + siteName + " not found in data.txt");
        } catch (IOException e) {
            System.out.println("An error occurred while reading data.txt: " + e.getMessage());
        }
        return "";
    }

    
    
    public static void allRss() {
        try (BufferedReader reader = new BufferedReader(new FileReader("data.txt"))) {
            java.util.List<String> lines = new java.util.ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            
            for (int i = 0; i < lines.size(); i++) {
                String[] parts = lines.get(i).split(";");
                if (parts.length >= 3) {
                    String rssUrl = parts[2];
                    retrieveRssContent(rssUrl);
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading data.txt: " + e.getMessage());
        }
    }


    public static void removeURLinfile(String siteName) {
        File inputFile = new File("data.txt");
        File tempFile = new File("tempData.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            List<String> lines = new ArrayList<>();
            
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }

            boolean found = false;
            for (int i = 0; i < lines.size(); i++) {
                String currentLine = lines.get(i);
                String[] parts = currentLine.split(";");
                if (parts.length >= 3) {
                    String name = parts[1].trim();
                    if (name.equals(siteName)) {
                        found = true;
                        continue; 
                    }
                    writer.write(currentLine + System.lineSeparator());
                }
            }

            if (!found) {
                tempFile.delete();
                System.out.println("Couldn't find " + siteName + ".");
            } else {
                System.out.println("Removed " + siteName + " successfully.");
            }

        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }

        inputFile.delete();
        tempFile.renameTo(inputFile);
    }
    



    public static void retrieveRssContent(String rssUrl) {
        try {
            Document doc = Jsoup.connect(rssUrl).get();
            Elements itemElements = doc.select("item");

            for (int i = 0; i < 5 && i < itemElements.size(); ++i) {
                Element itemElement = itemElements.get(i);
                System.out.println("Title: " + getElementTextContent(itemElement, "title"));
                System.out.println("Link: " + getElementTextContent(itemElement, "link"));
                System.out.println("Description: " + getElementTextContent(itemElement, "description"));
                System.out.println("/*****\\");
            }
        } catch (IOException e) {
            System.out.println("Error in retrieving RSS content for " + rssUrl + ": " + e.getMessage());
        }
    }

    private static String getElementTextContent(Element parentElement, String tagName) {
        Element element = parentElement.selectFirst(tagName);
        if (element != null) {
            return element.text();
        }
        return "";
    }
    
    public static String[] extractSiteInfo(String websiteUrl) {
        String[] siteInfo = new String[3];

        try {
            
            Document doc = Jsoup.connect(websiteUrl).get();

            String title = doc.title();
            siteInfo[0] = title;

            String rssUrl = doc.select("link[type='application/rss+xml']").attr("abs:href");
            siteInfo[1] = rssUrl;

            
        } catch (MalformedURLException e) {
            System.out.println("Invalid URL format!");
            return new String[]{"", ""};
        } catch (IOException e) {
            System.out.println("An error occurred while connecting to the website: " + e.getMessage());
            return new String[]{"", ""};
        }

        return siteInfo;
    }

    private static Scanner scanner = new Scanner(System.in); 

    @SuppressWarnings("resource")
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        System.out.println("Welcome to RSS Reader!");

        for (choice = -1; choice != 4; ) {
            System.out.println("Type a valid number for your desired action:");
            System.out.println("[1] Show updates");
            System.out.println("[2] Add URL");
            System.out.println("[3] Remove URL");
            System.out.println("[4] Exit");
            choice = Integer.parseInt(scanner.nextLine()); 

            switch (choice) {
                case 1:
                    showUpdates();
                    break;
                case 2:
                    addURL();
                    break;
                case 3:
                    removeURL();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice! Please enter a valid number.");
            }
        }

        scanner.close();
        
    }

    

   

    private static boolean searchUrl(String url) {
        List<String> lines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("data.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }

            for (int i = 0; i < lines.size(); i++) {
                if (lines.get(i).contains(url)) {
                    return true;
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }

        return false;
    }

    private static void removeURL() {
        @SuppressWarnings("resource")
        Scanner scanner = new Scanner(System.in);
        System.out.println("please enter website URL to remove:");
        String urlToRemove = scanner.nextLine();
        removeURLinfile(urlToRemove);
    }

    
 
    private static ArrayList<String> readTitlesFromFile(String filename) {
        ArrayList<String> titles = new ArrayList<>();
        List<String> lines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            
            for (int i = 0; i < lines.size(); i++) {
                String[] parts = lines.get(i).split(";");
                if (parts.length >= 1) {
                    titles.add(parts[0]);
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
        
        return titles;
    }


    private static void addURL() {
        System.out.println("please enter wbsite URL to add:");
        String url = scanner.nextLine();
        
        if (searchUrl(url)) {
            System.out.println(url+" already exists.");
            return;
        }

        String[] siteInfo = extractSiteInfo(url);
        String websiteName = siteInfo[0];
        String rssUrl = siteInfo[1];

        String output = websiteName + ";" + url;

        if (!rssUrl.isEmpty()) {
            output += ";" + rssUrl;
        } else {
            System.out.println("RSS URL not found!");
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data.txt", true))) {
            writer.write(output);
            writer.newLine();
            System.out.println("URL "+url+" added successfully!");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }
    }

    
 
}
